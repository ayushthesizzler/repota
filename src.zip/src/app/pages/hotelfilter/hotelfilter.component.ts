import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hotelfilter',
  templateUrl: './hotelfilter.component.html',
  styleUrls: ['./hotelfilter.component.scss']
})
export class HotelfilterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
