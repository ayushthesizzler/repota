import { HotelsortingPipe } from './hotelsorting.pipe';

describe('HotelsortingPipe', () => {
  it('create an instance', () => {
    const pipe = new HotelsortingPipe();
    expect(pipe).toBeTruthy();
  });
});
