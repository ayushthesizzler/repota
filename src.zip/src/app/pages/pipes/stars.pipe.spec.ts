import { StarsPipe } from './stars.pipe';

describe('StarsPipe', () => {
  it('create an instance', () => {
    const pipe = new StarsPipe();
    expect(pipe).toBeTruthy();
  });
});
