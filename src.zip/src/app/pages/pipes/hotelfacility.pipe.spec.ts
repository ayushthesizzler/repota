import { HotelfacilityPipe } from './hotelfacility.pipe';

describe('HotelfacilityPipe', () => {
  it('create an instance', () => {
    const pipe = new HotelfacilityPipe();
    expect(pipe).toBeTruthy();
  });
});
