import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import { RouterModule } from "@angular/router";
import { NgxSpinnerModule } from "ngx-spinner";
import { BsDropdownModule } from "ngx-bootstrap/dropdown";
import { ProgressbarModule } from "ngx-bootstrap/progressbar";
import { TooltipModule } from "ngx-bootstrap/tooltip";
import { CollapseModule } from "ngx-bootstrap/collapse";
import { TabsModule } from "ngx-bootstrap/tabs";
import { PaginationModule } from "ngx-bootstrap/pagination";
import { AlertModule } from "ngx-bootstrap/alert";
import { BsDatepickerModule } from "ngx-bootstrap/datepicker";
import { CarouselModule } from "ngx-bootstrap/carousel";
import { ModalModule } from "ngx-bootstrap/modal";
import { JwBootstrapSwitchNg2Module } from "jw-bootstrap-switch-ng2";
import { PopoverModule } from "ngx-bootstrap/popover";

import { IndexComponent } from "./index/index.component";

import { HeaderComponent } from "./header/header.component";
import { FooterComponent } from "./footer/footer.component";
import { BookFlightComponent } from "./book-flight/book-flight.component";
import { LandingPageContentComponent } from "./landing-page-content/landing-page-content.component";
import { FlightComponent } from "./flight/flight.component";
import { FilterSidenavComponent } from "./filter-sidenav/filter-sidenav.component";
import { BookHotelComponent } from "./book-hotel/hotel.component";
import { HotelComponent } from "./hotel/hotel.component";
import { SortingPipe } from "./pipes/sorting.pipe";
import { StopPipe } from "./pipes/stop.pipe";
import { FilterbycompanyPipe } from "./pipes/filterbycompany.pipe";
import { RegisterpageComponent } from "./registerpage/registerpage.component";
import { LoginComponent } from "./login/login.component";
import { httpInterceptorProviders } from "./auth/auth-interceptor";
import { RatingModule } from "ng-starrating";
import { ErrorpageComponent } from './errorpage/errorpage.component';
import { HotelsortingPipe } from './pipes/hotelsorting.pipe';
import { HotelfilterComponent } from './hotelfilter/hotelfilter.component';
import { StarsPipe } from './pipes/stars.pipe';
import { HotelfacilityPipe } from './pipes/hotelfacility.pipe';
@NgModule({
  imports: [
    CommonModule,
    BrowserModule,
    FormsModule,
    RatingModule,
    RouterModule,
    NgxSpinnerModule,
    BsDropdownModule.forRoot(),
    ProgressbarModule.forRoot(),
    TooltipModule.forRoot(),
    PopoverModule.forRoot(),
    CollapseModule.forRoot(),
    JwBootstrapSwitchNg2Module,
    TabsModule.forRoot(),
    PaginationModule.forRoot(),
    AlertModule.forRoot(),
    BsDatepickerModule.forRoot(),
    CarouselModule.forRoot(),
    ModalModule.forRoot()
  ],
  declarations: [
    IndexComponent,
    RegisterpageComponent,
    HeaderComponent,
    FooterComponent,
    BookFlightComponent,
    LandingPageContentComponent,
    FlightComponent,
    FilterSidenavComponent,
    BookHotelComponent,
    HotelComponent,
    SortingPipe,
    StopPipe,
    FilterbycompanyPipe,
    LoginComponent,
    ErrorpageComponent,
    HotelsortingPipe,
    HotelfilterComponent,
    StarsPipe,
    HotelfacilityPipe
  ],
  exports: [
    IndexComponent,
  
    RegisterpageComponent,
   
  ],
  providers: [httpInterceptorProviders]
})
export class PagesModule {}
