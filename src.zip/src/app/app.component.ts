import {
  Component,
  OnInit,
  Renderer,
  HostListener,
  Inject
} from "@angular/core";
import { Location } from "@angular/common";
import { DOCUMENT } from "@angular/common";
import { HttpClient } from "@angular/common/http";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.scss"]
})
export class AppComponent implements OnInit {
  constructor(
    private renderer: Renderer,
    public location: Location,
    @Inject(DOCUMENT) document,
    private http: HttpClient
  ) {}
  @HostListener("window:scroll", ["$event"])
  onWindowScroll(e) {
    if (window.pageYOffset > 100) {
      var element = document.getElementById("navbar-top");
      if (element) {
        element.classList.remove("navbar-transparent");
        element.classList.add("bg-danger");
      }
    } else {
      var element = document.getElementById("navbar-top");
      if (element) {
        element.classList.add("navbar-transparent");
        element.classList.remove("bg-danger");
      }
    }
  }
  ngOnInit() {
    this.onWindowScroll(event);
    this.http.get(
      `http://developer.goibibo.com/api/search/?app_id=a9ee56df&app_key=6c005d96918ae1f33946e316ceb58a27&format=json&source=BLR&destination=BBI&dateofdeparture=20191220&seatingclass=E&adults=1&children=0&infants=0&counter=100`
    ).subscribe((data) => {console.log(data)});
  }
}
